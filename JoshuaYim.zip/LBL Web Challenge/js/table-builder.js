var nodeTableStarter = '<tr class="node-entry"></tr>';
var nodeEntry = '<td>%data%</td>';
var nodeCapacity = '<td>%data%</td>';
var nodeFileCount = '<td>%data%</td>';
var nodeFileSize = '<td>%data%</td>';
var nodePercent = '<td>%data%</td>';

var distTableStarter = '<tr class="dist-entry"></tr>';
var distFileEntry = '<td>%data%</td>';
var distNodeEntry = '<td>%data%</td>';